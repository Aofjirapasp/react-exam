import React from 'react';
import './App.css';
import { Button, Table, Form, Pagination, PaginationItem, PaginationLink, CustomInput } from 'reactstrap';

function App() {
  return (
    <Form className= "table-form">
        <div className="container">
        <div className="text-success" align = "center"> <h2>Table-Form</h2></div>
        </div> 
        <br />

        <Pagination aria-label="Page-navigation">
    <PaginationItem>
        <PaginationLink first href="#" />
      </PaginationItem>
      <PaginationItem>
        <PaginationLink previous href="#" />
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href="#">
          1
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href="#">
          2
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href="#">
          3
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href="#">
          4
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink href="#">
          5
        </PaginationLink>
      </PaginationItem>
      <PaginationItem>
        <PaginationLink next href="#" />
      </PaginationItem>
      <PaginationItem>
        <PaginationLink last href="#" />
      </PaginationItem>
    </Pagination>

    <CustomInput type="checkbox" id="exampleCustomInline" label="Select All" inline />
    <Button color="secondary">Delete</Button>{' '}
    <Table striped>
    <thead>
      <tr>   
        <th></th>
        <th>Name</th>
        <th>Gender</th>
        <th>Mobile Phone</th>
        <th>Nationality</th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row"><CustomInput type="checkbox" id="exampleCustomCheckbox" label="" /></th>
        <td>Ratvadee Sagarik</td>
        <td>female</td>
        <td>+66079862651</td>
        <td>thai</td>
        <td>edit/delete</td>
      </tr>
      <tr>
      <th scope="row"><CustomInput type="checkbox" id="exampleCustomCheckboxx" label="" /></th>
        <td>Kangsadan Poosee</td>
        <td>female</td>
        <td>+660827774991</td>
        <td>thai</td>
        <td>edit/delete</td>
      </tr>
      <tr>
      <th scope="row"><CustomInput type="checkbox" id="exampleCustomCheckboxxx" label="" /></th>
        <td>Risa Pansakul</td>
        <td>female</td>
        <td>+660819956782</td>
        <td>thai</td>
        <td>edit/delete</td>
      </tr>
      <tr>
      <th scope="row"><CustomInput type="checkbox" id="exampleCustomCheckboxxxx" label="" /></th>
        <td>Sawi Tri</td>
        <td>female</td>
        <td>+66120119988</td>
        <td>american</td>
        <td>edit/delete</td>
      </tr>
      <tr>
      <th scope="row"><CustomInput type="checkbox" id="exampleCustomCheckboxxxxx" label="" /></th>
        <td>Attapon Sagarik</td>
        <td>male</td>
        <td>+660939077930</td>
        <td>laos</td>
        <td>edit/delete</td>
      </tr>
    </tbody>
  </Table>
  </Form>
  );
}

export default App;
